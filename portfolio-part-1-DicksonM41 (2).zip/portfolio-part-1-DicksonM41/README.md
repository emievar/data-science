# portfolio-part-1-DicksonM41
portfolio-part-1-DicksonM41 created by GitHub Classroom

Project Title: Portfolio Part 1 by Dickson Mai(4707799)
Language: Python 3

Libraries Used:
    Pandas
    Numpy
    Matplotlib.pyplot
    Seaborn

Readable Files:
    Portfolio_1_questions (Jupyter Source File)
    The E-commerce Dataset (Comma Separated Values File)

==DESCRIPTION== 

Jupyter file used to analysis the e-commerce dataset contain with in the project. 